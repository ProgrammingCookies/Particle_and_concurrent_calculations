#include <mpi.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "common.h"
#include <stddef.h>

//
//  benchmarking program
//
int main( int argc, char **argv )
{    
    //
    //  process command line parameters
    //
    if( find_option( argc, argv, "-h" ) >= 0 )
    {
        printf( "Options:\n" );
        printf( "-h to see this help\n" );
        printf( "-n <int> to set the number of particles\n" );
        printf( "-o <filename> to specify the output file name\n" );
        return 0;
    }
    
    int n = read_int( argc, argv, "-n", 1000 );
    char *savename = read_string( argc, argv, "-o", NULL );
    
    //
    //  set up MPI
    //
    int n_proc, rank;
    MPI_Init( &argc, &argv );
    MPI_Comm_size( MPI_COMM_WORLD, &n_proc );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    
    //
    //  allocate generic resources
    //
    FILE *fsave = savename && rank == 0 ? fopen( savename, "w" ) : NULL;
    particle_t *particles = (particle_t*) malloc( n * sizeof(particle_t) );
    
    MPI_Datatype PARTICLE;
    MPI_Type_contiguous( 6, MPI_DOUBLE, &PARTICLE );
    MPI_Type_commit( &PARTICLE );
    
    //
    //  set up the data partitioning across processors
    //
    int particle_per_proc = (n + n_proc - 1) / n_proc;
    int *partition_offsets = (int*) malloc( (n_proc+1) * sizeof(int) );
    for( int i = 0; i < n_proc+1; i++ )
        partition_offsets[i] = min( i * particle_per_proc, n );
    
    int *partition_sizes = (int*) malloc( n_proc * sizeof(int) );
    for( int i = 0; i < n_proc; i++ )
        partition_sizes[i] = partition_offsets[i+1] - partition_offsets[i];
    
    //
    //  allocate storage for local partition
    //
    int nlocal = partition_sizes[rank];
    particle_t *local = (particle_t*) malloc( nlocal * sizeof(particle_t) );
    
    //
    //  initialize and distribute the particles (that's fine to leave it unoptimized)
    //
    set_size( n );
    if( rank == 0 )
        init_particles( n, particles );
    MPI_Scatterv( particles, partition_sizes, partition_offsets, PARTICLE, local, nlocal, PARTICLE, 0, MPI_COMM_WORLD );
    

     /* create a type for struct car */
    const int nitems=6;
    int          blocklengths[6] = {2,2,2,2,2,2};
    MPI_Datatype types[2] = {MPI_DOUBLE, MPI_DOUBLE,MPI_DOUBLE,MPI_DOUBLE,MPI_DOUBLE,MPI_DOUBLE};
    MPI_Datatype mpi_particle_type;
    MPI_Aint     offsets[6];

    offsets[0] = offsetof(particle_t, x);
    offsets[1] = offsetof(particle_t, y);
    offsets[2] = offsetof(particle_t, vx);
    offsets[3] = offsetof(particle_t, vy);
    offsets[4] = offsetof(particle_t, ax);
    offsets[5] = offsetof(particle_t, ay);

    MPI_Type_create_struct(nitems, blocklengths, offsets, types, &mpi_particle_type);
    MPI_Type_commit(&mpi_particle_type);
    //
    //  simulate a number of time steps
    //
    double simulation_time = read_timer( );


    for( int step = 0; step < NSTEPS; step++ )
    {
        std::vector<particle_t *> sendList;
        particle_t particleRecieved;
        MPI_Request request;
        MPI_Request sendRequest;
        particle_t *part;
         if(rank == 0){//The one sending out the particles
            for(int i = 0; i < nrElem*nrElem; i++){
                int y = i/nrElem;
                int x = i%nrElem;
                std::vector<particle_t *> *element = &mat.at(y).at(x);
                    for(int z = 0; z < element -> size(); z++){ //Goes through each particle in each matrix
                        part = element -> at(z);
                        
                        MPI_TAG st;
                        MPI_Wait(&sendRequest,&st); //it's not allowed to change sendList until the previous message has been sent.
                        //this is how far it is allowed to go before the message has been fully sent

                        sendList.push_back(part);
                        part -> ax = part -> ay = 0; // Sets acceleration to 0
                        for(int g = -1; g <= 1; g++){ //Applies forces from every particle on adjacet and the same matrix element
                            for(int h = -1; h <= 1; h++){
                                if(x+g >= 0 && x+g < nrElem && y+h >= 0 && y+h < nrElem){
                                    std::vector<particle_t *> *checkAgainst = &mat.at(y+h).at(x+g);
                                    for(int gh = 0; gh < checkAgainst -> size(); gh++){ 
                                        if(g != 0 || h != 0 || gh != z){// an if-statement so it doesn't apply force to itself
                                            sendList.push_back((checkAgainst -> at(gh)));
                                        }
                                    }
                            }
                        }
                    }
                    //Sending to some ready thread
                    int sentAWay = 0;
                    while(sentAWay == 0){
                        for(int k = 1; k < n_proc; k++){
                            MPI_Irecv(&particleRecieved, 1, mpi_particle_type, k,0, MPI_COMM_WORLD, &request);
                            MPI_test(&request, &recievedFlag, &status);
                        if(recievedFlag != 0){
                            //TODO - check if this is a good way to replace the old particle with the new one. 
                            *part = particleRecieved;
                            MPI_Isend( &sendList, sendList.size(), mpi_particle_type, k, 0, MPI_COMM_WORLD, &sendRequest); //MPI_COMM_WORLD? Change
                            sentAWay = 1;
                            break;
                        }
                     }
                    }
                }
            }//End of for-loop for each particle
            sendList.at(0) = 0;
            //Barrier needed or something so it waits until it has gotten every particle back with it's new values
            for(int i = 1; i < n_proc; i++){
                MPI_Send( &sendList, sendList.size(), mpi_particle_type, k, 0, MPI_COMM_WORLD, &sendRequest);
            }
            
            

        } else {
            while(1){//Does this until it gets the message to break the loop
             sendList.resize(20); //Makes space for 20 particles, I don't know how many we need to make space for - TODO
             MPI_Status status;
             MPI_recv(&sendList, 20, 0,0,MPI_COMM_WORLD, &status); //Status?
             if(sendList.at(0) == 0){
                 break;
             }
            for(int i = 0; i < sendList.size(); i++){
                apply_force(*sendList.at(0), *sendList.at(i));
            }
            //MPI_Isend()
            MPI_Send(&sendList.at(0), 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
         }//End of while
        }

        
        //
        //  save current step if necessary (slightly different semantics than in other codes)
        //
        if(rank == 0)[
            if( fsave && (step%SAVEFREQ) == 0 ){
                MPI_Allgatherv( local, nlocal, PARTICLE, particles, partition_sizes, partition_offsets, PARTICLE, MPI_COMM_WORLD );
                    save( fsave, n, particles );
            }
                
        ]
        
        
        
        //
        //  move particles
        //
        for( int i = 0; i < nlocal; i++)
            move( local[i] );
    }
    simulation_time = read_timer( ) - simulation_time;
    
    if( rank == 0 )
        printf( "n = %d, n_procs = %d, simulation time = %g s\n", n, n_proc, simulation_time );
    
    //
    //  release resources
    //
    free( partition_offsets );
    free( partition_sizes );
    free( local );
    free( particles );
    if( fsave )
        fclose( fsave );
    
    MPI_Finalize();
    
    return 0;
}

/* 


channel: 

//apply force

struct paior:
particle: 
list med rutor som den påverkar: 

send(struct pair messsage, bla ,bla)


channel: 

//apply force på sina egna

//SKicka dom av dess egna partiklar som påverkar andra.

//väntar in meddelanden från andra kanaler

//kör apply force med dom nya partiklar som den har fått från andra kanaler

//nu är vi klara med apply force



//flyttar på alla sina egna partiklar

//skickar de partiklar som flyttar till en annan rutas område

//Väntar på ta emot meddelande




*/
