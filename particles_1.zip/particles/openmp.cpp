#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "common.h"
#include <vector>
#include <omp.h>

//
//  benchmarking program
//
int main( int argc, char **argv )
{    
    if( find_option( argc, argv, "-h" ) >= 0 )
    {
        printf( "Options:\n" );
        printf( "-h to see this help\n" );
        printf( "-n <int> to set the number of particles\n" );
        printf( "-o <filename> to specify the output file name\n" );
        return 0;
    }
    
    int n = read_int( argc, argv, "-n", 1000 );
    int numThreads = read_int( argc, argv, "-p", 2 );

    char *savename = read_string( argc, argv, "-o", NULL );
    
    FILE *fsave = savename ? fopen( savename, "w" ) : NULL;
    particle_t *particles = (particle_t*) malloc( n * sizeof(particle_t) );
    set_size( n );
    init_particles( n, particles );
    double max_velocity = getCutoff();
    double size2 = getSize();
    int nrElem = (int) (size2/max_velocity) + 1;

    std::vector<std::vector<std::vector<particle_t *>>> mat;
    //mat.reserve(nrElem);

 //Create and init locks for each square(a.k.a matrix element)
   /* omp_lock_t lockList[nrElem*nrElem];

    for(int i = 0; i < nrElem*nrElem; i++){
        omp_init_lock(&lockList[i]); //The locks are initalized
    }
    omp_lock_t testLock;
    omp_init_lock(&testLock); */


    for(int i = 0; i < nrElem; i++){
        std::vector<std::vector<particle_t *>> another = {};
        for(int x = 0; x < nrElem; x++){
            std::vector<particle_t *> an;
            another.push_back(an);
        }
        mat.push_back(another);
        
    }

/*
    void *argd1;
    argd1 = malloc(sizeof(struct matrixElement*) * nrElem*nrElem);
    struct matrixElement * arg3 = (struct matrixElement *) argd1;

 */
   




    initMatrix(mat, particles, n , nrElem, max_velocity); //Not core dumped in initmatrix


     //Check if pointers point right, it's initialized right
    int nrRight = 0;
    for(int i = 0; i < n;i++){
        particle_t *ps = particles + i;
            int y = (int) ((*(particles + i)).y/max_velocity);
            int xz = (int) ((*(particles + i)).x/max_velocity);

            std::vector<particle_t *> el = mat.at(i/nrElem).at(i%nrElem);

        int rightPlace = 0;
        for(int x = 0; x < el.size(); x++){
            if(el.at(x) == ps){
                rightPlace = 1;
            }
        }
        if(rightPlace){
            nrRight++;
        }
    }

    //
    //  simulate a number of time steps
    //
    double simulation_time = read_timer( );
    double timeSpentInRepo = 0;
    double applTime = 0;

    double startRepo = 0;
    double startAppl = 0;

    
    omp_set_num_threads(numThreads);

    for( int step = 0; step < NSTEPS; step++ ) //Tror den core dumpar eftersom antalet partiklar på en plats byggs upp tills det är över gränsen, kolla.
    {
        //
        //  compute forces
        //
        //#pragma master
        //{
            startAppl = read_timer( );
        //}
        #pragma omp parallel for
            for(int i = 0; i < nrElem*nrElem; i++){
                int y = i/nrElem;
                int x = i%nrElem;
                std::vector<particle_t *> *element = &mat.at(y).at(x);
                    for(int z = 0; z < element -> size(); z++){ //Goes through each particle in each matrix
                    
                        
                        particle_t *part = element -> at(z);
                        part -> ax = part -> ay = 0; // Sets acceleration to 0
                        for(int g = -1; g <= 1; g++){ //Applies forces from every particle on adjacet and the same matrix element
                            for(int h = -1; h <= 1; h++){
                                if(x+g >= 0 && x+g < nrElem && y+h >= 0 && y+h < nrElem){
                                    std::vector<particle_t *> *checkAgainst = &mat.at(y+h).at(x+g);
                                    
                                    for(int gh = 0; gh < checkAgainst -> size(); gh++){ 
                                        if(g != 0 || h != 0 || gh != z){// an if-statement so it doesn't apply force to itself
                                            apply_force(*part, *(checkAgainst -> at(gh)));
                                        }
                                    }
                            }
                        }
                    }
                }
            }
        
        //#pragma master
        //{
            applTime += read_timer() - startAppl;
        //}
        //Barrier();
        //
        //  move particles
        //
      //  printf("stuck here");
      //  fflush(stdout);


        #pragma omp parallel for
        for( int i = 0; i < n; i++ ) { //Move so that it repositions and moves at the same time?
            move( particles[i] );
        }

        //#pragma master
        //{
            startRepo = read_timer();
       // }
        for(int i = 0; i < 3; i++){
            for(int h = 0; h < 3; h++){
                    #pragma omp parallel for
                    for(int z = i*nrElem + h; z < nrElem*nrElem; z++ ){
                        int y = z/nrElem;
                        int x = z%nrElem;
                        if(y%3 == i && x%3 == h){
                            repositionParallell(mat,particles,n,max_velocity,x,y);
                        }
                    }
            }
        }   
        


        
        //#pragma master 
        //{
            timeSpentInRepo += read_timer() - startRepo;
        //}
        

        //
        //  save if necessary
        //
        //#pragma master
        //{
            if( fsave && (step%SAVEFREQ) == 0 )
            save( fsave, n, particles );
        //}
        
    }
    
    simulation_time = read_timer( ) - simulation_time;
    
    printf( "n = %d, simulation time = %g seconds\n", n, simulation_time );
    printf("Number of Threads: %d \n", numThreads);
    printf("Time in repo: %g, time in appl: %g newnew\n", timeSpentInRepo, applTime);

   // for(int i = 0; i < nrElem*nrElem; i++){
    //    omp_destroy_lock(&lockList[i]);
   // }
    free( particles );
    if( fsave )
        fclose( fsave );
    
    return 0;
}
